$(document).ready(function(){
		      $('.siema').slick({
		        slidesToShow: 8,
  				slidesToScroll: 6,
		       	dots: false,
			    prevArrow: false,
			    nextArrow: false
		      });
                  $('.wrapper-lista-carusel-li').slick({
                    slidesToShow: 8,
                        slidesToScroll: 6,
                        dots: false,
                      prevArrow: false,
                      nextArrow: false
                  });



		 });